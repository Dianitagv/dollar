﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EF_CodeFirst_6
{
   class Program
   {
      static void Main(string[] args)
      {
         using (ColegioContext context = new ColegioContext())
         {
            var alumnos = context.Alumnos.ToList();
            foreach (var alumno in alumnos)
            {
               Console.WriteLine(alumno.nombre + "   " + alumno.ponderado);
            }
         }
      }
   }
}
